# Crear los vectores
vector_X <- c(230)
vector_X2 <- c(100)
vector_y1 <- c(3)
vector_y2 <- c(5)
Vector_I1 <- c(3589)
Vector_I2 <- c(160)
# Organizar los valores en una matriz de 2x2
matriz_tiempo <- matrix(c(vector_X, vector_y1, vector_X2, vector_y2), nrow = 2, ncol = 2)
matriz_tiempo

# Calcular la determinante de la matriz
det(matriz_tiempo)
# Calcular la matriz inversa:
cofactor <- function(matrix, i, j) {
  minor_matrix <- matrix[-i, -j, drop = FALSE]
  return(det(minor_matrix) * (-1)^(i + j))
}

# : Creación de la matriz cofactor_matrix
n <- nrow(matriz_tiempo)
m <- ncol(matriz_tiempo)
cofactor_matrix <- matrix(0, nrow = n, ncol = m)

for (i in 1:n) {
  for (j in 1:m) {
    cofactor_matrix[i, j] <- cofactor(matriz_tiempo, i, j)
  }
}
# Calcular Matriz Adjunta
adjunta <- t(cofactor_matrix)
adjunta
# Calcular la matriz inversa de matriz_tiempo
matriz_inversa <- solve(matriz_tiempo)
matriz_inversa
# Combinar los vectores en una matriz de 3 filas:
# Define los valores de I1 e I2
I1 <- 3589
I2 <- 160
# Crea el vector de constantes:
vector_I <- matrix(c(I1, I2))
vector_I
solucion<-solve(matriz_tiempo,vector_I)
solucion
#Costo de mano de obra:
vector_Hora_X <- c(3)
vector_Desarrollador_Novato_Y<-c(31)
vector_Hora_y<-c(5)
vector_Desarrollador_Experto_X<-c(3)
vector_COSTO_EXPERTO_X<-c(900)
vector_COSTO_NOVATO_Y<-c(400)

# Realizar la multiplicación y multiplicar por 20:
resultado <- (vector_Hora_X * vector_Desarrollador_Experto_X * vector_COSTO_EXPERTO_X) * 20

cat("El costo de los desarrolladores expertos es:", resultado)
# Definir los vectores
vector_Hora_X <- c(3)
vector_Desarrollador_Novato_Y <- c(31)
vector_Hora_y <- c(5)
vector_Desarrollador_Experto_X <- c(3)
vector_COSTO_EXPERTO_X <- c(900)
vector_COSTO_NOVATO_Y <- c(400)

# Realizar las multiplicaciones y calcular el costo de los desarrolladores expertos
costo_experto <- (vector_Hora_X * vector_Desarrollador_Experto_X * vector_COSTO_EXPERTO_X) * 20

# Mostrar el resultado del costo de los desarrolladores expertos
cat("El costo de los desarrolladores expertos es:", costo_experto, "\n")

# Realizar la otra multiplicación
costo_novato <- (vector_Hora_y * vector_Desarrollador_Novato_Y * vector_COSTO_NOVATO_Y) * 20

# Mostrar el resultado de la otra multiplicación
cat("El costo de los desarrolladores novatos es:", costo_novato, "\n")
# Calcular el costo total de la mano de obra sumando los costos de expertos y novatos
costo_total <- costo_experto + costo_novato

# Mostrar el resultado del costo total de la mano de obra
cat("El costo total de la mano de obra es:", costo_total, "\n")

